# A Website for my Dad

Checkout the
[Safe Group Website](https://sanimart.netlify.app/)
